package com.example.puzzlecrafter

data class ImageStats(
    val imageUri: String,
    val diffs: String
)