package com.example.puzzlecrafter

data class ImageStats(
    val imageUri: String,
    val diffs: String // Например, "4,16,32"
)